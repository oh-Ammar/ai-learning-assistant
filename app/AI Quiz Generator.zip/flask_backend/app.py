# File: app.py

from flask import Flask, request, jsonify
import spacy
import numpy as np
import hashlib
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load spaCy model
nlp = spacy.load("en_core_web_sm")

def get_stable_vector(word):
    """Generate a stable pseudo-random 300-dim vector from a word hash"""
    h = hashlib.sha256(word.lower().encode()).digest()
    np.random.seed(int.from_bytes(h[:4], 'little'))  # fixed seed
    return np.random.rand(300)

def get_vector(word):
    try:
        vec = nlp.vocab.get_vector(word.lower())
        if vec is not None and len(vec) == 300:
            return vec
        else:
            return get_stable_vector(word)
    except:
        return get_stable_vector(word)

@app.route("/pos_tag_text", methods=["POST"])
def pos_tag_text():
    data = request.get_json()
    text = data.get("text", "")
    doc = nlp(text)
    tagged_tokens = [
        {"text": token.text, "pos": token.pos_} for token in doc if not token.is_space
    ]
    return jsonify(tagged_tokens)

@app.route("/check_answers", methods=["POST"])
def check_answers():
    data = request.get_json()
    user_answers = data.get("user_answers", [])
    correct_answers = data.get("correct_answers", [])

    results = []

    for user_ans, correct_ans in zip(user_answers, correct_answers):
        user_doc = nlp(user_ans)
        correct_doc = nlp(correct_ans)

        user_vectors = [get_vector(token.text) for token in user_doc if token.text.strip()]
        correct_vectors = [get_vector(token.text) for token in correct_doc if token.text.strip()]

        if not user_vectors or not correct_vectors:
            similarity = 0.0
            is_correct = False
        else:
            user_vec = np.mean(user_vectors, axis=0)
            correct_vec = np.mean(correct_vectors, axis=0)

            # Final double-check on shape before cosine similarity
            if user_vec.shape[0] != 300 or correct_vec.shape[0] != 300:
                similarity = 0.0
                is_correct = False
            else:
                similarity = float(cosine_similarity([user_vec], [correct_vec])[0][0])
                is_correct = similarity >= 0.75

        results.append({
            "user_answer": user_ans,
            "correct_answer": correct_ans,
            "similarity": similarity,
            "is_correct": is_correct
        })

    return jsonify(results)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
