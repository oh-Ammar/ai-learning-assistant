package com.example.aiquizgenerator.questions;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class QuestionFactory {

    public static class Token {
        public String text;
        public String pos;

        public Token(String text, String pos) {
            this.text = text;
            this.pos = pos;
        }
    }

    public static List<QuestionBank> generateQuestionsFromTokens(JSONArray posTaggedJson) {
        List<QuestionBank> questions = new ArrayList<>();
        List<Token> tokens = new ArrayList<>();

        try {
            for (int i = 0; i < posTaggedJson.length(); i++) {
                JSONObject obj = posTaggedJson.getJSONObject(i);
                tokens.add(new Token(obj.getString("text"), obj.getString("pos")));
            }

            for (int i = 0; i < tokens.size() - 2; i++) {
                Token t1 = tokens.get(i);
                Token t2 = tokens.get(i + 1);
                Token t3 = tokens.get(i + 2);

                // Enhanced Rule: PROPN + VERB + NOUN  => "Who [VERB] [NOUN]?"
                if (t1.pos.equals("PROPN") && t2.pos.equals("VERB") && t3.pos.equals("NOUN")) {
                    String questionText = "Who " + t2.text + " " + t3.text + "?";
                    String modelAnswer = t1.text;
                    questions.add(new WhQuestion(questionText, modelAnswer));
                    continue;
                }

                // Enhanced Rule: NOUN + VERB => "What does/ do [NOUN] [VERB]?"
                if (t1.pos.equals("NOUN") && t2.pos.equals("VERB")) {
                    String noun = t1.text;
                    String verb = t2.text;

                    // Simple plural check
                    boolean isPlural = noun.toLowerCase().endsWith("s") && !noun.toLowerCase().endsWith("ss");
                    String helperVerb = isPlural ? "do" : "does";

                    String questionText = "What " + helperVerb + " " + noun + " " + verb + "?";
                    String modelAnswer = noun;
                    questions.add(new WhQuestion(questionText, modelAnswer));
                    continue;
                }

                // Drop redundant/low-quality rule: NUM → When did it happen?
                // It produced many invalid questions. We'll skip this for now.
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return questions;
    }
}
