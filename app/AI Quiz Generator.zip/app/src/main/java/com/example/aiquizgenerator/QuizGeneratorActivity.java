package com.example.aiquizgenerator;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.aiquizgenerator.helpers.OCRProcessor;
import com.example.aiquizgenerator.questions.QuestionBank;
import com.example.aiquizgenerator.questions.QuestionFactory;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import android.widget.Button;


public class QuizGeneratorActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PICK_FILE_REQUEST_CODE = 2;
    private Button submitAnswersButton;
    private List<EditText> answerInputs = new ArrayList<>();

    private Button pasteTextButton, uploadDocButton, uploadImageButton, generateQuizButton;
    private EditText inputText;
    private ProgressBar progressBar;
    private ScrollView questionScrollView;
    private LinearLayout questionContainer;

    private OCRProcessor ocrProcessor;
    private List<QuestionBank> generatedQuestions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PDFBoxResourceLoader.init(getApplicationContext());
        setContentView(R.layout.activity_quiz_generator);

        pasteTextButton = findViewById(R.id.pasteTextButton);
        uploadDocButton = findViewById(R.id.uploadDocButton);
        uploadImageButton = findViewById(R.id.uploadImageButton);
        generateQuizButton = findViewById(R.id.generateQuizButton);
        inputText = findViewById(R.id.inputText);
        progressBar = findViewById(R.id.progressBar);
        questionScrollView = findViewById(R.id.questionScrollView);
        questionContainer = findViewById(R.id.questionContainer);
        submitAnswersButton = findViewById(R.id.submitAnswersButton);

        submitAnswersButton.setOnClickListener(v -> submitAnswers());

        ocrProcessor = new OCRProcessor();

        pasteTextButton.setOnClickListener(v -> pasteText());
        uploadDocButton.setOnClickListener(v -> openDocumentPicker());
        uploadImageButton.setOnClickListener(v -> openImagePicker());
        generateQuizButton.setOnClickListener(v -> generateQuizFromText());
    }

    private void pasteText() {
        inputText.setVisibility(View.VISIBLE);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void openDocumentPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, PICK_FILE_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            Uri fileUri = data.getData();
            if (fileUri != null) {
                if (requestCode == PICK_FILE_REQUEST_CODE) {
                    extractTextFromDocument(fileUri);
                } else if (requestCode == PICK_IMAGE_REQUEST) {
                    extractTextFromImage(fileUri);
                }
            }
        }
    }

    private void extractTextFromDocument(Uri fileUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(fileUri);
            String extractedText = new DocumentToText().extractTextFromPDF(inputStream);
            inputText.setText(extractedText);
            inputText.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to process document.", Toast.LENGTH_SHORT).show();
        }
    }

    private void extractTextFromImage(Uri fileUri) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), fileUri);
            String extractedText = ocrProcessor.extractTextFromImage(bitmap);
            inputText.setText(extractedText);
            inputText.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to process image.", Toast.LENGTH_SHORT).show();
        }
    }

    private void generateQuizFromText() {
        String text = inputText.getText().toString().trim();

        if (text.isEmpty()) {
            Toast.makeText(this, "Please enter or upload some text first.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        try {
            JSONObject json = new JSONObject();
            json.put("text", text);

            ApiClient.post("/pos_tag_text", json.toString(), new ApiClient.ApiCallback() {
                @Override
                public void onSuccess(String response) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONArray tokens = new JSONArray(response);
                            generatedQuestions = QuestionFactory.generateQuestionsFromTokens(tokens);
                            displayQuestions();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(QuizGeneratorActivity.this, "Failed to parse questions.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(QuizGeneratorActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show();
                    });
                }
            });

        } catch (Exception e) {
            progressBar.setVisibility(View.GONE);
            e.printStackTrace();
            Toast.makeText(this, "Error preparing request.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayQuestions() {
        questionContainer.removeAllViews();
        for (QuestionBank q : generatedQuestions) {
            TextView questionView = new TextView(this);
            questionView.setText(q.formatForDisplay());
            questionView.setTextSize(18);
            questionView.setPadding(16, 16, 16, 16);

            EditText answerInput = new EditText(this);
            answerInputs.add(answerInput);

            questionContainer.addView(questionView);
            questionContainer.addView(answerInput);
        }
        questionScrollView.setVisibility(View.VISIBLE);
        submitAnswersButton.setVisibility(View.VISIBLE);

    }
    private void submitAnswers() {
        progressBar.setVisibility(View.VISIBLE);

        JSONArray userAnswers = new JSONArray();
        JSONArray correctAnswers = new JSONArray();

        try {
            for (int i = 0; i < generatedQuestions.size(); i++) {
                String userAnswer = answerInputs.get(i).getText().toString().trim();
                String correctAnswer = generatedQuestions.get(i).getModelAnswer();
                userAnswers.put(userAnswer);
                correctAnswers.put(correctAnswer);
            }

            JSONObject json = new JSONObject();
            json.put("user_answers", userAnswers);
            json.put("correct_answers", correctAnswers);

            ApiClient.post("/check_answers", json.toString(), new ApiClient.ApiCallback() {
                @Override
                public void onSuccess(String response) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONArray results = new JSONArray(response);
                            int correctCount = 0;
                            int total = results.length();

                            StringBuilder resultSummary = new StringBuilder();

                            for (int i = 0; i < total; i++) {
                                JSONObject res = results.getJSONObject(i);
                                boolean isCorrect = res.getBoolean("is_correct");
                                double similarity = res.getDouble("similarity");

                                resultSummary.append(i + 1).append(". ")
                                        .append(isCorrect ? "✅ Correct" : "❌ Incorrect")
                                        .append(" (Similarity: ").append(String.format("%.2f", similarity)).append(")\n\n");

                                if (isCorrect) correctCount++;
                            }

                            int percentage = (int) (((double) correctCount / total) * 100);
                            resultSummary.insert(0, "Score: " + percentage + "%\n\n");

                            // Show results
                            showResultDialog(resultSummary.toString());

                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(QuizGeneratorActivity.this, "Error parsing results.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onFailure(String error) {
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(QuizGeneratorActivity.this, "Error: " + error, Toast.LENGTH_SHORT).show();
                    });
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Error preparing answers.", Toast.LENGTH_SHORT).show();
        }
    }
    private void showResultDialog(String resultSummary) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Quiz Results");
        builder.setMessage(resultSummary);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.setCancelable(false);
        builder.show();
    }

}
