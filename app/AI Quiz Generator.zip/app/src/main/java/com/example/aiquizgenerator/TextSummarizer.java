package com.example.aiquizgenerator;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.*;

public class TextSummarizer {

    private static final String TAG = "TextSummarizer";
    private static final String HF_API_URL = "https://api-inference.huggingface.co/models/facebook/bart-large-cnn";
    private static final String HF_API_KEY = "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";

    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String OPENAI_API_KEY = "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";

    private static OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();

    public interface SummarizationCallback {
        void onSummarizationComplete(String result);
    }

    public interface QuizGenerationCallback {
        void onQuizGenerationComplete(String result);
    }

    public static void summarizeTextAsync(String text, SummarizationCallback callback) {
        new SummarizationTask(callback).execute(text);
    }

    public static void generateQuizAsync(String text, QuizGenerationCallback callback) {
        new QuizGenerationTask(callback).execute(text);
    }

    // ----------- SUMMARIZATION TASK -------------

    private static class SummarizationTask extends AsyncTask<String, Void, String> {
        private SummarizationCallback callback;

        SummarizationTask(SummarizationCallback callback) {
            this.callback = callback;
        }

        @Override
        protected String doInBackground(String... texts) {
            String text = texts[0];
            if (text == null || text.trim().isEmpty()) {
                return "Input text is empty or null.";
            }

            try {
                text = text.substring(0, Math.min(text.length(), 1024));

                String json = "{"
                        + "\"inputs\":\"" + escapeJsonString(text) + "\","
                        + "\"parameters\": {\"min_length\": 50}"
                        + "}";

                Request request = new Request.Builder()
                        .url(HF_API_URL)
                        .addHeader("Authorization", "Bearer " + HF_API_KEY)
                        .post(RequestBody.create(json, MediaType.parse("application/json")))
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String result = response.body().string();
                    return parseBartSummary(result);
                } else {
                    Log.e(TAG, "Failed response: " + response.code());
                    return "Error summarizing text. API returned an error.";
                }
            } catch (IOException e) {
                Log.e(TAG, "Error summarizing text.", e);
                return "Error summarizing text. Please check your internet connection.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (callback != null) {
                callback.onSummarizationComplete(result);
            }
        }
    }

    private static String parseBartSummary(String response) {
        try {
            JSONArray jsonArray = new JSONArray(response);
            if (jsonArray.length() > 0) {
                JSONObject firstItem = jsonArray.getJSONObject(0);
                if (firstItem.has("summary_text")) {
                    return firstItem.getString("summary_text");
                }
            }
            return "No summary generated.";
        } catch (Exception e) {
            Log.e(TAG, "Error parsing BART summary response.", e);
            return "Error parsing summary.";
        }
    }

    // ----------- QUIZ GENERATION TASK -------------

    private static class QuizGenerationTask extends AsyncTask<String, Void, String> {
        private QuizGenerationCallback callback;

        QuizGenerationTask(QuizGenerationCallback callback) {
            this.callback = callback;
        }

        @Override
        protected String doInBackground(String... texts) {
            String text = texts[0];
            if (text == null || text.trim().isEmpty()) {
                return "Input text is empty or null.";
            }

            try {
                text = text.substring(0, Math.min(text.length(), 2000));
                String prompt = "Generate a multiple choice quiz based on the following text. Make the difficulty of each question ranging from easiest to hardest. "
                        + "Each question should have 4 options labeled A-D. Mark the correct answer with an asterisk (*). "
                        + "Text: \"" + escapeJsonString(text) + "\"";

                JSONObject message = new JSONObject();
                message.put("role", "user");
                message.put("content", prompt);

                JSONArray messages = new JSONArray();
                messages.put(message);

                JSONObject json = new JSONObject();
                json.put("model", "gpt-3.5-turbo");
                json.put("messages", messages);
                json.put("temperature", 0.7);

                Request request = new Request.Builder()
                        .url(OPENAI_API_URL)
                        .addHeader("Authorization", "Bearer " + OPENAI_API_KEY)
                        .addHeader("Content-Type", "application/json")
                        .post(RequestBody.create(json.toString(), MediaType.parse("application/json")))
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String result = response.body().string();
                    return parseOpenAIResponse(result);
                } else {
                    Log.e(TAG, "Failed OpenAI response: " + response.code());
                    return "Error generating quiz. API returned an error.";
                }
            } catch (Exception e) {
                Log.e(TAG, "Error generating quiz.", e);
                return "Error generating quiz. Please check your internet connection.";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (callback != null) {
                callback.onQuizGenerationComplete(result);
            }
        }
    }

    private static String parseOpenAIResponse(String response) {
        try {
            JSONObject json = new JSONObject(response);
            JSONArray choices = json.getJSONArray("choices");
            if (choices.length() > 0) {
                JSONObject firstChoice = choices.getJSONObject(0);
                JSONObject message = firstChoice.getJSONObject("message");
                return message.getString("content");
            }
            return "No quiz generated.";
        } catch (Exception e) {
            Log.e(TAG, "Error parsing OpenAI response.", e);
            return "Error parsing quiz.";
        }
    }

    // ----------- JSON ESCAPE -------------

    private static String escapeJsonString(String text) {
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}